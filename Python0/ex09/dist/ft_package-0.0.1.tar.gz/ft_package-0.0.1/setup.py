from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    packages=find_packages(),
    description="Sample package for Piscine Python",
    author="kuehara",
    license="MIT",
)
