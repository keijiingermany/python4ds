def swap(a, b):
    return b, a
