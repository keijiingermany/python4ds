from ft_package import count_in_list, swap

print(count_in_list(["a", "b", "a"], "a"))
print(swap(10, 20))
