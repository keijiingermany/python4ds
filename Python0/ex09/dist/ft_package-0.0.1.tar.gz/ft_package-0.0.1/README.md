# ft_package
Sample package for Piscine Python Ex09.
